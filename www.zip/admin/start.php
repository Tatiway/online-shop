<?php

mb_internal_encoding("UTF-8");
$path = "../".PATH_SEPARATOR."../lib".PATH_SEPARATOR."comp";
set_include_path(get_include_path().PATH_SEPARATOR.$path);