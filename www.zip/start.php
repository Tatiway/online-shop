<?php
	mb_internal_encoding("UTF-8");
	$path = "lib".PATH_SEPARATOR."comp";
	set_include_path($path);
?>